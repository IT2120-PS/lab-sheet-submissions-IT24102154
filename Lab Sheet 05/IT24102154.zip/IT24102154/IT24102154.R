setwd('C:\\Users\\it24102154\\Desktop\\IT24102154')
getwd()

## Question 01
 

## Question 02
histogram<-hist(Delivery_Times$Delivery, main="Histogram of Delivery Times",xlab = "Delivery Time",ylab = "Frequency",breaks = seq(20, 70,length = 10),right = FALSE)

## Question 03
##This is a Right-skewed distribution

## Question 04
breaks <- histogram$breaks
freq <- histogram$counts
mid <- histogram$mids

classes <- c()

for(i in 1:length(breaks)-1){
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
  cbind(Classes = classes, Frequency = freq)
}
cbind(Classes = classes, Frequency = freq)

cum.freq <- cumsum(freq)

new<-c(0, cum.freq)

plot(breaks, new, type = 'o', main="Cumalative Frequency Polygon (Ogive)", xlab = "Delivery Time", ylab = "Cumulative Frequency")
cbind(Upper = breaks, CumFreq = new)

